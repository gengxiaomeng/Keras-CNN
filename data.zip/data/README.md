The dataset folder does not contain all the images required to train the model. Please use your own dataset.
